export class Creditcard {
//     firstName: String;
//     lastName: String;
//     address: String;
//     contactNumber: number;
//     creditnum: number;
//     expiryDate: Date;
//     cvv: number;
// }
}