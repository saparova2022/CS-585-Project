import { Creditcard } from './creditcard';

describe('Creditcard', () => {
  it('should create an instance', () => {
    expect(new Creditcard()).toBeTruthy();
  });
});
