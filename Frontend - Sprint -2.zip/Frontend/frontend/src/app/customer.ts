export interface ICustomer {
  userId: string;
  name: string;
  password: string;
  role: string;
  contactNumber: number;
}
