export interface IFood {
  dishId: number;
  dishName: string;
  description: string;
  price: number;
  type: string;
}
