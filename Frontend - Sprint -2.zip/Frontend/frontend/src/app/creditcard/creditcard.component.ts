import { Component } from '@angular/core';
import { Creditcard } from '../../creditcard';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-creditcard',
  templateUrl: './creditcard.component.html',
  styleUrls: ['./creditcard.component.css']
})
export class CreditcardComponent {
   OrderPrice: number=0;
   CreditCardForm: any;
   Amount : any;
   TotalAmount : any;
   Tax : any;

  constructor(private fb:FormBuilder) { 
    this.CreditCardForm={
    firstName: '',
    lastName: '',
    address: '',
    contactNumber: '',
    creditnum: '',
    expiryDate: '',
    cvv: ''
    }
  }



  ngOnInit()
  {
    this.Amount = localStorage.getItem("Amount");
    this.TotalAmount = localStorage.getItem("TotalAmount");
    this.Tax = this.Amount * (18/100);

  }

}
