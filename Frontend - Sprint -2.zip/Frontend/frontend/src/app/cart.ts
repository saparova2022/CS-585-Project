export interface ICart {
  cartId: number,
  userId : string,
  dishId: number,
  dishName: string,
  price: number,
  quantity : number
}
