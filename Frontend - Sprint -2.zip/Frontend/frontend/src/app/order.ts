export interface IOrder {
  userId: string;
  dishes: string;
  orderDate: string;
  price: number;
}
