# Food-Delivery-Web-App-SpringAndAngular
Online Food Delivery Application : A web-app with Spring and Aagular


  Server : Spring -
    Spring Web,
    Spring Data JDBC,
    Spring MySql Server,
    Devtools
    
    
  UI : Angular
    
