package com.cts.ofds;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cts.ofds.dao.CartDaoImpl;
import com.cts.ofds.dao.DishDaoImpl;
import com.cts.ofds.dao.OrderDetailsDaoImpl;
import com.cts.ofds.dao.UserDaoImpl;
import com.cts.ofds.model.Cart;
import com.cts.ofds.model.Dish;
import com.cts.ofds.model.OrderDetails;
import com.cts.ofds.model.User;
import com.cts.ofds.service.CartService;
import com.cts.ofds.service.DishService;
import com.cts.ofds.service.OrderDetailsService;
import com.cts.ofds.service.UserService;

@SuppressWarnings("unused")
@SpringBootApplication
public class OfdsApplication {
	
	private static UserService userService;
	private static OrderDetailsService orderService;
	private static DishService dishService;
	private static CartService cartService;
	private static CartDaoImpl cartDao;
	
	@Autowired
	public OfdsApplication(CartDaoImpl cartDao,CartService cartService,UserService userService,OrderDetailsService orderService,DishService dishService) {
		OfdsApplication.userService = userService;
		OfdsApplication.orderService = orderService;
		OfdsApplication.dishService = dishService;
		OfdsApplication.cartService = cartService;
		OfdsApplication.cartDao = cartDao;
	}
	
	public static void main(String[] args) 
	{
		SpringApplication.run(OfdsApplication.class, args);
	}
}
