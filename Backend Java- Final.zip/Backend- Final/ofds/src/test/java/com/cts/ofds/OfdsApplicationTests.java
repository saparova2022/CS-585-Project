package com.cts.ofds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfdsApplicationTests {

	@Test
	void contextLoads() {
	}

}
